/** Sebrianne Ferguson homework 1 part 3 CS 151
 * Note: Although I did write the code in Java myself, I got the help of Nate Munger
 * to come up with the algorithm and understand how to do this recursively.
 

* Implement the method Encoding.morseCodes(int m, int n) that yields 
 * a set of all Morse code strings with m dots and n dashes. For example, 
 * morseCodes(2, 1) yields a set with ..- .-. ..- -.. in some order. 
 * Hint: Recursion. Start with a dot, and then what? Start with a dash, and then what?
 */

import java.util.*; //from the skeleton

public class Encoding {
	
	public static Set<String> morseCodes(int m, int n) {
	      Set<String> result = new TreeSet<>(); //from the skeleton
	      
	      if (m==0 && n==0) { //this would be the base case
	    	  result.add(""); //no characters so you would return an empty string
	      }
	      
	      if (m > 0) {  //if there are still dots to add
	    	  for (String k: morseCodes(m-1,n)) { //for every entry currently in the tree set
	    		  result.add(k+"."); //add a dot to it and add it to a new set
	    		  //therefore, these would be the set that is 1+ the length of the last one
	    	  }
	      }
	      if (n > 0) { //same thing for the dashes
	    	  for (String k: morseCodes(m,n-1)) {
	    		  result.add(k+"-");
	    	  }
	      }
	      
	      return result; //returns the tree set that has entries length m+n
	      
	   }
}