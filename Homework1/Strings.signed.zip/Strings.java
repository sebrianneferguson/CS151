/**Sebrianne Ferguson CS 151 Homework 1 Problem 2
 * I did not get help on this program.

In Java, implement the method Strings.uniqueLetters(String str) 
 * that returns a string of those letters that only occur once in str, 
 * in the same order that they appear in the original. 
 * For example, uniqueLetters("harrasses") should return "he". 
 */

import java.util.ArrayList;

public class Strings {
	   
	public static String uniqueLetters(String str) {
		
		ArrayList<String> letters = new ArrayList<String>();
		ArrayList<String> bad = new ArrayList<String>();
		
		for (int i = 0; i < str.length(); i++) {
			
			String sub = str.substring(i, i+1); //the letter we're looking at
			
			if (bad.contains(sub)) { //don't need to look and see if there's more than one of it 
				letters.remove(sub);
			}
			else {
				int counter = 1; //keeps track of how many repetitions
				for (int j = i + 1; j < str.length(); j++) {
					if (str.substring(j,j+1).equals(sub)) {
						counter++;
					}
				}
				if (counter == 1) {
					letters.add(sub);
				}
				else {
					bad.add(sub);
				}
			}
		}
		
		String result = "";
		
		for (int i = 0; i < letters.size(); i++) {
			result += letters.get(i);
		}
		
		return result;
		
	}
}